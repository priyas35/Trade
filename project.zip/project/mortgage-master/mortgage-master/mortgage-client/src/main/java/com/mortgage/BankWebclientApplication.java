package com.mortgage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@SpringBootApplication
@EnableEurekaClient
public class BankWebclientApplication implements WebMvcConfigurer{
	
	public static final String STOCK_SERVICE_URL = "http://stock-service";
	

	public static void main(String[] args) {
		SpringApplication.run(BankWebclientApplication.class, args);
	}
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Bean
	public ClientStockService clientStockService(){
		return new RemoteStockRepository(STOCK_SERVICE_URL);
	}
	
	
	@Bean
	public ClientPlaceorderService clientPlaceorderService(){
		return new RemotePlaceorderRepository(STOCK_SERVICE_URL);
	}
	

}
