package com.mortgage;

import java.util.List;
import org.apache.log4j.Logger;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class ClientController {
	
	int orderid;
	int ID;
	int UserID;
	
	@Autowired
	ClientStockService clientStockService;
	
	@Autowired
	ClientPlaceorderService clientPlaceorderService;

	

	@RequestMapping("/home")
	public ModelAndView home(ModelAndView model) {
		model.addObject("stock", new Stock());
		model.setViewName("home");
		return model;
	}
	
	
	
	
	@PostMapping("/getstock")
	public ModelAndView getStock(@ModelAttribute Stock sk) {
		ModelAndView modelAndView = new ModelAndView();
		this.UserID = sk.getUserid();
		List<Stock> stock = clientStockService.getStock(sk.getUserid());
		modelAndView.addObject("stock", stock);
		modelAndView.setViewName("stock");
		return modelAndView;
	}
	
	@RequestMapping("/getallstock")
	public ModelAndView getAllStock() {
		ModelAndView modelAndView = new ModelAndView();
		List<Stock> stock = clientStockService.getAllStock();
		modelAndView.addObject("stock", stock);
		modelAndView.setViewName("allstock");
		return modelAndView;
	}
	
	@RequestMapping("/buy")
	public ModelAndView buy() {
		ModelAndView modelAndView = new ModelAndView();
		Placeorder placeorder = new Placeorder();
		modelAndView.addObject("placeorder", placeorder);
		modelAndView.setViewName("stockform");
		return modelAndView;
	}
	
	@RequestMapping("/buystock")
	public ModelAndView buyStock(@ModelAttribute Placeorder placeorder) {
		ModelAndView modelAndView = new ModelAndView();
		String id = clientPlaceorderService.buyStock(placeorder);
		if (id.equals("Loan Applied")) {
			modelAndView.setViewName("cart");
		} 
		return modelAndView;
	}
	
	
	@RequestMapping("/buywithpayment")
	public ModelAndView buywithPayment(HttpServletRequest request) {
		ModelAndView modelAndView = new ModelAndView();

		int totalamount = Integer.parseInt(request.getParameter("totalamount"));
	
			Placeorder placeorder = new Placeorder();
			
			placeorder.setOrderid(orderid);
			placeorder.setTotalamount(totalamount);
			boolean res = clientPlaceorderService.buywithPayment(placeorder);
			
				modelAndView.setViewName("dashboard");
		
		return modelAndView;
	}
	
	
	@RequestMapping("/totalamount/{id}")
	public ModelAndView totalAmount(@PathVariable("id") int id) {
		orderid = id;
		int totalamount = clientPlaceorderService.totalamount(orderid);
		System.out.println(totalamount);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("totalamount", totalamount);
		modelAndView.setViewName("totalamount");
		return modelAndView;
	}
	
	
	@RequestMapping("/getorders")
	public ModelAndView getorders() {
		ModelAndView modelAndView = new ModelAndView();
		
		List<Placeorder> orders = clientPlaceorderService.getorders(UserID);
		modelAndView.addObject("orders", orders);
		modelAndView.setViewName("payment");
		return modelAndView;
	}
	
	
	

	

	

}
