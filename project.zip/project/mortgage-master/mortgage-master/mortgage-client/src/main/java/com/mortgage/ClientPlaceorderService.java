package com.mortgage;

import java.util.List;

public interface ClientPlaceorderService {
	
	
	public String buyStock(Placeorder placeorder);

	public int totalamount(int id);
	
	public List<Placeorder> getorders(int userid);
	
	public boolean buywithPayment(Placeorder placeorder);
	

}
