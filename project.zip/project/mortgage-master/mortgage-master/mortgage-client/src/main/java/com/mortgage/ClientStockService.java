package com.mortgage;

import java.util.List;

public interface ClientStockService {
	
	
	public List<Stock> getStock(int userid);

	public List<Stock> getAllStock();
	

}
