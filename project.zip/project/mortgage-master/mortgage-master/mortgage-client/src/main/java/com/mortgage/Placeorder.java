package com.mortgage;


public class Placeorder {
	
	private int orderid;
	
	
	
	private int quantityordered;
	

	private double totalamount;
	
	
	private int id;
	
	private int userid;
	
	
	
	
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public double getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(double totalamount) {
		this.totalamount = totalamount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getQuantityordered() {
		return quantityordered;
	}
	
	
	public void setQuantityordered(int quantityordered) {
		this.quantityordered = quantityordered;
	}
	
	
	

}
