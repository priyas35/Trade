package com.mortgage;


public class Placeorder {
	
	private int orderid;
	
	
	
	private int quantityordered;
	
	private String itemname;
	
	

	private double totalamount;
	
	
	
	private int userid;
	
	private int id;
	
	
	
	
	
	
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public double getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(double totalamount) {
		this.totalamount = totalamount;
	}
	
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getQuantityordered() {
		return quantityordered;
	}
	
	
	public void setQuantityordered(int quantityordered) {
		this.quantityordered = quantityordered;
	}
	
	
	

}
