package com.mortgage;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class RemotePlaceorderRepository implements ClientPlaceorderService {
	
	@Autowired
	protected RestTemplate restTemplate;
	
	protected String serviceUrl;
	
	public RemotePlaceorderRepository(String serviceUrl) {
		this.serviceUrl = serviceUrl.startsWith("http") ? serviceUrl
				: "http://" + serviceUrl;
	}



	@Override
	public String buyStock(Placeorder placeorder) {
		
		ResponseEntity<String> res = restTemplate.postForEntity(serviceUrl + "/stock/buystock", placeorder, String.class);
		return res.getBody();
	}
	
	@Override
	public int totalamount(int orderid) {
		ResponseEntity<Integer> amount = restTemplate.getForEntity(serviceUrl + "/stock/totalamount/" + orderid, Integer.class);
		return amount.getBody();
	}
	
	
	@Override
	public boolean buywithPayment(Placeorder placeorder) {
		ResponseEntity<Boolean> result = restTemplate.postForEntity(serviceUrl + "/stock/buywithpayment", placeorder, boolean.class);
		return result.getBody();
	}
	
	
	@Override
	public List<Placeorder> getorders(int userid) {
		Placeorder[] placeorders = restTemplate.getForObject(serviceUrl + "/stock/" + userid + "/getorders", Placeorder[].class);
		return Arrays.asList(placeorders);
	}
	

	

}
	
//	@Override
//	public List<Account> getAllAccounts() {
//		Account[] accounts = restTemplate.getForObject(serviceUrl+"/accounts", Account[].class);
//		return Arrays.asList(accounts);
//	}
//
//	@Override
//	public Account getAccount(String number) {
//		return restTemplate.getForObject(serviceUrl + "/accounts/{id}",
//				Account.class, number);
//	}


