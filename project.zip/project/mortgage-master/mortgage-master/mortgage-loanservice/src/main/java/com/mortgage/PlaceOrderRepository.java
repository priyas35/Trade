package com.mortgage;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface PlaceOrderRepository extends CrudRepository<Placeorder, Integer>{
	
	
	
    public Placeorder getPlaceorderByOrderid(int orderid);
    
    
	
	public Placeorder getPlaceorderByIdAndOrderid(int id, int orderid);



	public List<Placeorder> getPlaceorderByUserid(int userid);
	
    

}