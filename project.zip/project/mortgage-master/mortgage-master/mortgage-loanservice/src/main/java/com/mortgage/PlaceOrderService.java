package com.mortgage;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public  class PlaceOrderService {
    
	@Autowired
	PlaceOrderRepository placeOrderRepository;
	
	@Autowired
	StockRepository stockRepository;
	
	
	public String buyStock(Placeorder placeorder) {
		String res = "";
		/*
		 * Placeorder placeorder2 =
		 * placeOrderRepository.getPlaceorderByIdAndOrderid(placeorder.getId(),
		 * placeorder.getOrderid());
		 */
		
		
		Placeorder placeorder3 = placeOrderRepository.save(placeorder);
							
								res = "Loan Applied";
							
						
		return res;
	}
	
	
	public int totalAmount(int orderid) {
		Placeorder placeorder = placeOrderRepository.getPlaceorderByOrderid(orderid);
		Stock stock=stockRepository.getStockById(placeorder.getId());
		int totalammount = 0;
		int quantityOrdered=placeorder.getQuantityordered();
		int price=stock.getPrice();
		double brokerage=stock.getBrokerage();
		totalammount=(int) (quantityOrdered*price+((brokerage*100)/100));
		placeOrderRepository.save(placeorder);
		return totalammount;
	}
	
	
	public boolean buywithPayment(Placeorder placeorder) {
		boolean res = false;
		Placeorder placeorder2 = placeOrderRepository.getPlaceorderByOrderid(placeorder.getOrderid());
		
		placeorder2.setTotalamount(placeorder.getTotalamount());
		
		placeOrderRepository.save(placeorder2);
		res = true;
		
		return res;
	}
	
	public List<Placeorder> getorders(int userid) {
		return  placeOrderRepository.getPlaceorderByUserid(userid);
	}
	
	
	
}
