package com.mortgage;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="placeorder")
public class Placeorder {
	@Id
	@Column
	private int orderid;
	
	
	@Column
	private int quantityordered;
	
	@Column
	private double totalamount;
	
	@Column
	private int id;
	
	@Column
	private int userid;
	
	
	
	
	
	
	
	
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public double getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(double totalamount) {
		this.totalamount = totalamount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getQuantityordered() {
		return quantityordered;
	}
	
	
	public void setQuantityordered(int quantityordered) {
		this.quantityordered = quantityordered;
	}
	
	
	

}
