package com.mortgage;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="placeorder")
public class Placeorder {
	@Id
	@Column
	private int orderid;
	
	
	@Column
	private int quantityordered;
	
	@Column
	private String itemname;
	
	@Column
	private double totalamount;
	

	@Column
	private int userid;
	
	@Column
	private int id;
	
	
	
	
	
	

	
	
	
	
	
	

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public double getTotalamount() {
		return totalamount;
	}
	public void setTotalamount(double totalamount) {
		this.totalamount = totalamount;
	}

	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getQuantityordered() {
		return quantityordered;
	}
	
	
	public void setQuantityordered(int quantityordered) {
		this.quantityordered = quantityordered;
	}
	
	
	

}
