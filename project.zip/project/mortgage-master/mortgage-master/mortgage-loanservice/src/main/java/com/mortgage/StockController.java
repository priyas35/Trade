package com.mortgage;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/stock")
public class StockController {

	@Autowired
	StockService stockService;
	
	@Autowired
	StockRepository stockRepository;
	
	@Autowired
	PlaceOrderService placeOrderService;
	
	
	@RequestMapping("/{userid}/getstock")
	public List<Stock> getStockByStockid(@PathVariable("userid") int userid) {
		return stockService.getStock(userid);
	}
	
	
	
	@RequestMapping("/getallstock")
	public List<Stock> getAllStock() {
	    return   (List<Stock>) stockRepository.findAll();
	}
	
	
	@RequestMapping("/buystock")
	public String applyloan(@RequestBody Placeorder placeorder) {
		return placeOrderService.buyStock(placeorder);
	}
	
	
	@RequestMapping("/totalamount/{orderid}")
	public int totalAmount(@PathVariable("orderid") int orderid) {
		return placeOrderService.totalAmount(orderid);
	}
	
	@RequestMapping("/buywithpayment")
	public boolean buywithPayment(@RequestBody Placeorder placeorder) {
		return placeOrderService.buywithPayment(placeorder);
	}
	
	@RequestMapping("/{userid}/getorders")
	public List<Placeorder> getorders(@PathVariable("userid") int userid) {
		return placeOrderService.getorders(userid);
	}
	
	

	
	

}
