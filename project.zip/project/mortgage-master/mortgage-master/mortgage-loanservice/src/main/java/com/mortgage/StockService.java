package com.mortgage;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StockService {

	@Autowired
	StockRepository stockRepository;

	
	public List<Stock> getStock(int userid) {
		return stockRepository.getStockByUserid(userid);
	}
	
	
	
	
	
}
